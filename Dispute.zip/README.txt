Projet : Création d'une messagerie instantannée
Année : 5A SAGI - 2021-2022
Élèves :

  - Grégoire ACHARD
  - Bastien GARNIER
  - Vivien JOLY

Pour lancer le serveur : 
- Faire : "python main.py" dans une console à la racine du projet.
- Vous connecter à "localhost:5000" sur le navigateur de votre choix.

